# @sparkwing/sdk

Declare Sparkwing pipelines in TypeScript. The host schedules jobs and owns
placement, retries, risk authorization, storage and credentials. SDK processes
build declarations and execute the bodies and closures the host requests.

```ts
import { definePipeline, main } from "@sparkwing/sdk";

definePipeline({
  name: "check",
  args: [{ name: "target", type: "string", default: "all" }],
  secrets: [{ name: "DEPLOY_TOKEN", optional: true }],
  plan(plan, run) {
    const build = plan
      .job("build", async (ctx) => {
        await ctx.exec(["npm", "run", "build"]).run();
        return { target: run.args.target };
      })
      .artifacts("dist/**");
    plan
      .job("report", async (ctx) => {
        const output = await ctx.output(build);
        await ctx.summary(`Built ${output?.target}`);
      })
      .needs(build)
      .consumes(build, { into: "build-output" });
  },
});

await main();
```

`name` is the registration key. The `entrypoint` of a `sparkwing.yaml`
pipeline names it, and the run context's `pipeline` carries the invoked name.

Declare allowed child runs with `job.startsChildren("deploy")` for the parent
repository or `job.startsChildrenIn("gh:123", "publish")` for an explicit canonical
repository key. Calls append targets and can be chained.

Use an exact package version in `.sparkwing/package.json`. Its version selects
the matching engine. The package requires Node.js 22.18 or later. The public
API is [index.d.ts](index.d.ts).

Numeric duration options use milliseconds. Memory uses bytes. Omitted options
remain unset. Explicit zero remains zero, including an
indefinite approval timeout. Argument values stay strings, including `int64`.
The host validates arguments after describe and before planning. Empty defaults
mean no default. Required arguments with non-empty defaults are refused. NaN and
infinity are refused. Help and describe inspect declarations without requiring
invocation values. Errors come from host preparation as `invalid_args`.
Duration arguments use Go syntax such as `1h30m`, including `0`, `+0` and `-0`.
String-array arguments use comma splitting, trimming and empty-item removal in
both the raw argument map and typed values. The host trims enum choices and checks
each list item. Scalar string values keep their whitespace.
SDK declarations and direct `toDoc()` calls rely on host validation of argument
schemas, plan graphs and secret declarations. Generated jobs carry argument
declarations in their job specification. The host validates and prepares values
from the accepted run snapshot after generation, then sends them with execution
requests. Enable `extra` for supplied flags that only a generator declares. Annotation locations are validated
by the host service; TypeScript retains transport type checks.
Initial jobs may only use argument declarations discovered by zero-input describe,
with job IDs allowed to change. The gated expansion path registers secrets for new
generated declarations before execution.

`Context` provides lazy secrets and plain variables, typed outputs, references,
annotations, summaries, acknowledged masking, OIDC, child runs and cleanup.
Command, Git, Docker, service and filesystem helpers use the same context
and cancellation signal. Memo helpers declare input recipes for host evaluation. Plan callbacks declare work; helpers that perform I/O
refuse calls during planning. Generated jobs reconstruct from recorded source
output. The host validates the reconstructed declarations against accepted state.

Step output reads stay within the current attempt. Before a step condition or
body runs, the host supplies the terminal predecessor state. A skipped predecessor
has no local output. A terminal step cannot run again in the same attempt.
Run facts stay read-only across planning and retries, including trigger details
and nested pull-request facts.
Cancellation reaches bodies and every closure kind. A callback that finishes
after cancellation still reports a failed invocation. The SDK acknowledges
cancellation after the selected operations finish and receive their own replies.
Closure evaluations run in request order. Canceling a queued evaluation returns
without calling its author code or waiting for the running closure. Overlapping
generator replays return the recorded declaration after the first evaluation.
Service scopes also reject after cancellation when their callback returns normally.
They remove their containers before rejecting. If removal fails, host cleanup
stays registered and the cancellation error is preserved.

Git fileset hashes omit files beneath literal directory paths in `.dockerignore`,
including paths written without a trailing slash. Included file edits still
change the hash.

The host starts `node <entry> --sw-node-protocol`. Protocol 2 begins with hello,
which supplies granted runner identity and an optional in-memory service binding.
Requests and frames use private pipes. Standard output and error remain author
output. No preload or environment bearer is used. The SDK does not filter debug
logs or assign job identity to log frames.

Package imports use Node's native CommonJS and ESM loading, including symlinked
dependencies installed by pnpm. Default and named exports follow Node's interop
rules for both entry imports and imports inside job callbacks.

Every encoded frame must fit the 17 MiB wire limit. Oversized logs fail before
writing. Typed job and step outputs also have a separate 16 MiB limit.
Generated declarations use the frame budget. The Sparkwing host masks output and
protocol payloads after receiving them from the SDK. Pipeline code run without a
Sparkwing host has unmasked logs and errors.

Memo helpers declare recipes in the plan. The executing host evaluates them
against its checkout and effective job environment, under the job admission
permit. Tracked inputs encode paths, entry types and file bytes or symlink target
text. Tree inputs include regular files and skip symlinks. Custom callbacks return
JSON values for host hashing. `memoKey` collects parts and performs no hashing.

On Windows, the host supplies decimal handles through
`--sw-protocol-handles <request>,<frame>`. A packaged native bridge converts them
to Node descriptors and clears inheritance before SDK tools spawn. Independently
imported modules may execute before SDK initialization.

Build and verify each bridge in its matching native Windows MSVC environment,
with Node and Go running on that architecture:

```sh
npm run release:native -- --version <engine-version> --headers <node-headers/include/node> --node-lib <node.lib> --arch x64
```

Repeat with `--arch arm64` on native Windows arm64. The command stamps both npm
manifests, builds the bridge and runs `TestNativeProtocol` and
`TestNativeConformance`. Missing, skipped or failed native tests stop the build.
Each output directory contains `protocol.node` and a `verification.json` record
bound to the engine version, bridge bytes and SDK sources.

Build both architectures from the same source and version. Transfer their output
directories to the package checkout, then assemble the package:

```sh
npm run release:pack -- --version <engine-version> --destination <output-directory>
```

The release package must contain `native/win32-x64/protocol.node` and
`native/win32-arm64/protocol.node`. `npm pack` refuses the development version
and inconsistent lockfile versions. It also checks both bridge files and their
architecture and DLL headers. Both matching native verification records are
required because header checks cannot prove that Node can load and use a bridge.
The bridge source is in [native/protocol.c](native/protocol.c). End users need
no compiler.

## Local dogfooding

On Linux or macOS, build a local package without Windows bridges:

```sh
npm ci
npm run pack:local -- --version <engine-version> --destination <output-directory>
```

This command builds the SDK and stamps a temporary package with the exact engine
release version. It leaves the source manifests unchanged. The tarball carries
`private: true`, so npm refuses publication even with `--ignore-scripts`.
Use `release:pack` with verified Windows bridges for published packages.
Local packages support Linux and macOS. They cannot run on Windows.

In the pipeline's package manifest, pin the tarball with
`"@sparkwing/sdk": "file:vendor/sparkwing-sdk-<engine-version>.tgz"` and run
`npm install` to record it in the lockfile. The tarball's package version selects
the exact engine, including any prerelease suffix. Commit the tarball inside the
repository if fetched checkouts need it. An editable SDK directory can use
`file:../sdk` after building and stamping that directory's package version.

For development, run `npm ci`, `npm run typecheck`, `npm test` and `npm run build`.
The build emits ESM into `dist/`; package exports expose only the public root.
The release process stamps `package.json` and its lockfile with the engine
release version. Hello reads that package version.

Run `npm run test:native` from this directory with the repository's Go toolchain
installed and `GOWORK=off` when a parent workspace points at another checkout.
The tests build the SDK and launch public-package fixtures with inherited
Unix descriptors or Windows argv handles. It exchanges requests and replies
using the Go contract types and check that a child tool cannot access the
protocol pipes. A second fixture runs the same v2 corpus as the Go SDK, including
strict plan validation, generated hashes, replay and canonical error envelopes. Use Node and Go for the same CPU architecture. On Windows,
build the matching native bridge first. Missing Node, TypeScript dependencies
or bridge binaries fail the test.

The Go acceptance suite also runs SDK boundary tests for the protocol scenarios.
These tests use native pipes, fake bound services and a temporary Git file remote.
Run the native pipe test on Windows to verify raw handles there. Controller
authorization, store transitions, artifact/memo persistence, real DinD and the
six placement paths require their corresponding integration hosts.
